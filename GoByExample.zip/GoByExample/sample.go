package main

import (
	"fmt"
	"sync"
)

func main() {
	tasks := make([]Task, 200)

	for i := 0; i < 200; i++ {
		tasks[i] = Task{ID: i + 1}
	}

	wp := WorkerPool{
		Tasks:       tasks,
		concurrency: 200,
	}

	wp.Run()
	fmt.Print("All Tasks has completed....")
}

type Task struct {
	ID int
}

func (t *Task) Process() {
	fmt.Printf("Procesing Tasks %d\n", t.ID)
}

type WorkerPool struct {
	Tasks       []Task
	concurrency int
	tasksChan   chan Task
	wg          sync.WaitGroup
}

func (wp *WorkerPool) worker() {
	for task := range wp.tasksChan {
		task.Process()
		wp.wg.Done()
	}
}

func (wp *WorkerPool) Run() {
	wp.tasksChan = make(chan Task, len(wp.Tasks))

	for i := 0; i < wp.concurrency; i++ {
		go wp.worker()
	}

	wp.wg.Add(len(wp.Tasks))
	for _, task := range wp.Tasks {
		wp.tasksChan <- task
	}

	close(wp.tasksChan)

	wp.wg.Wait()

}
