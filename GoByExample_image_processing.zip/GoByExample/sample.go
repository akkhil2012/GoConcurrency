package main

import (
	"fmt"
	"image"
	"image/jpeg"
	"log"
	"os"
	"sync"

	"github.com/nfnt/resize" // You can install it using: go get github.com/nfnt/resize
)

// Task represents a job for processing an image.
type Task struct {
	ImagePath string
	Width     uint
	Height    uint
}

// Worker function that processes tasks from the queue.
func worker(id int, tasks <-chan Task, wg *sync.WaitGroup) {
	defer wg.Done()
	for task := range tasks {
		processImage(task)
		fmt.Printf("Worker %d processed image: %s\n", id, task.ImagePath)
	}
}

// Process the image and save the resized version.
func processImage(task Task) {
	// Open the image file
	file, err := os.Open(task.ImagePath)
	if err != nil {
		log.Printf("Error opening image: %v\n", err)
		return
	}
	defer file.Close()

	// Decode the image
	img, _, err := image.Decode(file)
	if err != nil {
		log.Printf("Error decoding image: %v\n", err)
		return
	}

	// Resize the image
	resizedImg := resize.Resize(task.Width, task.Height, img, resize.Lanczos3)

	// Create a new file to save the resized image
	outputPath := "resized_" + task.ImagePath
	outFile, err := os.Create(outputPath)
	if err != nil {
		log.Printf("Error creating output file: %v\n", err)
		return
	}
	defer outFile.Close()

	// Save the resized image as JPEG
	err = jpeg.Encode(outFile, resizedImg, nil)
	if err != nil {
		log.Printf("Error encoding image: %v\n", err)
	}
}

// Main function to start the worker pool and process images.
func main() {
	const numWorkers = 4
	tasks := make(chan Task, 10)
	var wg sync.WaitGroup

	// Start the worker pool
	for i := 1; i <= numWorkers; i++ {
		wg.Add(1)
		go worker(i, tasks, &wg)
	}

	// Simulating image upload by adding tasks to the queue
	imagePaths := []string{"image1.jpg", "image2.jpg"} // Add paths of images to be processed
	for _, path := range imagePaths {
		tasks <- Task{ImagePath: path, Width: 800, Height: 600} // Resizing to 800x600
	}

	close(tasks) // Close the tasks channel after adding all tasks
	wg.Wait()    // Wait for all workers to finish

	fmt.Println("All images processed.")
}
